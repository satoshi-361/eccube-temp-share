<?php

namespace Plugin\EccubePaymentLite4;

use Eccube\Common\EccubeTwigBlock;

class GmoEpsilonTwigBlock implements EccubeTwigBlock
{
    /**
     * @return array
     */
    public static function getTwigBlock()
    {
        return [
        ];
    }
}
