<?php

namespace Plugin\PayPalCheckout\Exception;

class OtherPaymentMethodException extends PayPalCheckoutException
{
}
