<?php

namespace Plugin\PayPalCheckout\Exception;

/**
 * Class ReFoundSubscriptionPaymentException
 * @package Plugin\PayPalCheckout\Exception
 */
class ReFoundSubscriptionPaymentException extends PayPalCheckoutException
{
}
