<?php

namespace Plugin\PayPalCheckout\Exception;

/**
 * Class NotFoundCartException
 * @package Plugin\PayPalCheckout\Exception
 */
class NotFoundCartException extends PayPalCheckoutException
{
}
