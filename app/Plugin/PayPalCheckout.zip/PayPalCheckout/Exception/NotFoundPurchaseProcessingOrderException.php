<?php

namespace Plugin\PayPalCheckout\Exception;

/**
 * Class NotFoundPurchaseProcessingOrderException
 * @package Plugin\PayPalCheckout\Exception
 */
class NotFoundPurchaseProcessingOrderException extends PayPalCheckoutException
{
}
