<?php

namespace Plugin\PayPalCheckout\Exception;

use Exception;

/**
 * Class PayPalCheckoutException
 * @package Plugin\PayPalCheckout\Exception
 */
class PayPalCheckoutException extends Exception
{
}
