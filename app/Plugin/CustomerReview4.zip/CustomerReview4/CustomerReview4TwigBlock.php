<?php

namespace Plugin\CustomerReview4;

use Eccube\Common\EccubeTwigBlock;

class CustomerReview4TwigBlock implements EccubeTwigBlock
{
    /**
     * @return array
     */
    public static function getTwigBlock()
    {
        return [];
    }
}
